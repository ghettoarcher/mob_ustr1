package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText arg1;
    EditText arg2;
    Button  plus;
    Button minus;
    Button sep;
    Button mult;
    TextView result;

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_main);

        arg1 = (EditText) findViewById(R.id.arg1);
        arg2 = (EditText) findViewById(R.id.arg2);
        plus = (Button) findViewById(R.id.plus);
        minus = (Button) findViewById(R.id.minus);
        sep = (Button) findViewById(R.id.sep);
        mult = (Button) findViewById(R.id.mult);
        result = (TextView) findViewById(R.id.result);

        plus.setOnClickListener(this);
        minus.setOnClickListener(this);
//        sep.setOnClickListener(this);
//        mult.setOnClickListener(this);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View view) {
        float num1 = 0;
        float num2 = 0;
        float result = 0;

        if (TextUtils.isEmpty(arg1.getText().toString())
                || TextUtils.isEmpty(arg2.getText().toString())) {
            this.result.setText("Error!");
            return;
        }

        num1 = Float.parseFloat(arg1.getText().toString());
        num2 = Float.parseFloat(arg2.getText().toString());

        switch (view.getId()) {
            case R.id.plus:
                result = num1 + num2;
                this.result.setText(num1 + " + " + num2 + " = " + result);
                break;
            case R.id.minus:
                result = num1 - num2;
                this.result.setText(num1 + " - " + num2 + " = " + result);
                break;
            default:
                break;
        }
    }

    @SuppressLint("SetTextI18n")
    public void ClickMult(View view) {
        float num1;
        float num2;
        float result;

        if (TextUtils.isEmpty(arg1.getText().toString())
                || TextUtils.isEmpty(arg2.getText().toString())) {
            this.result.setText("Error!");
            return;
        }

        num1 = Float.parseFloat(arg1.getText().toString());
        num2 = Float.parseFloat(arg2.getText().toString());

        result = num1 * num2;
        this.result.setText(num1 + " * " + num2 + " = " + result);
    }

    @SuppressLint("SetTextI18n")
    public void ClickSep(View view) {
        float num1;
        float num2;
        float result;

        if (TextUtils.isEmpty(arg1.getText().toString())
                || TextUtils.isEmpty(arg2.getText().toString())) {
            this.result.setText("Error!");
            return;
        }

        num1 = Float.parseFloat(arg1.getText().toString());
        num2 = Float.parseFloat(arg2.getText().toString());

        if (num2 == 0) {
            this.result.setText("Error");
        } else {
            result = num1 / num2;
            this.result.setText(num1 + " / " + num2 + " = " + result);
        }
    }

}
